class BluetoothPrinterModel {
  int? id;
  String? deviceName;
  String? address;

  BluetoothPrinterModel({
    this.deviceName,
    this.address,
  });
}