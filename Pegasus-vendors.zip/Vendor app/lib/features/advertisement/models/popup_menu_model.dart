import 'package:flutter/material.dart';

class PopupMenuModel{
  final String title;
  final IconData icon;
  PopupMenuModel({required this.title, required this.icon});
}