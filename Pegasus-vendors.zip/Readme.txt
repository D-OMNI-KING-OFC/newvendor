If you need only the changed files for vendor app in V3.5 check the changed files from V3.4 to V3.5 folder
otherwise please use "Vendor app" folder.

Documentation - https://6ammart.app/documentation/